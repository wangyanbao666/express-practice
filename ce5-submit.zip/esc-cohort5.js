const fs = require("fs");
const path = require("path");

// qn 1
function gcd(a, b) {
    var ans = 1;
    if (a == b) {
        return a;
    }
    if (b > a) {
        var temp = a;
        a = b;
        b = temp;
    }
    for (let i = 1; i < a; i++)
        if (a % i == 0 && b % i == 0 && i > ans) {
            ans = i;
        }
    return ans;
}

// question 2
function parseCSV(fullpath) {
    if (fs.existsSync(fullpath)) {
        // split the files lines on newlines, and remove surrounding spaces:
        let rows = fs.readFileSync(fullpath)
            .toString()
            .trim()
            .split(/\s*\r?\n\s*/);

        // split each row on commas, and remove the surrounding spaces:
        rows = rows.map((row) => row.split(/\s*,\s*/));

        return rows;
    }
    console.log(`File ${fullpath} not found`);
    return [];
}

// ESC Cohort5 Exercise3 quicksort
// partition
function partition(input_list, low, high) {
    let pivot = input_list[high];
    let low_pointer = low;

    for (let i = low; i < high; i++) {
        if (input_list[i] < pivot) {
            // swap input_list[i] and input_list[low_pointer]
            let temp = input_list[low_pointer];
            input_list[low_pointer] = input_list[i];
            input_list[i] = temp;
            low_pointer++;
        }
    }
    // swap input_list[low_pointer] and input_list[high]
    let temp = input_list[low_pointer];
    input_list[low_pointer] = input_list[high];
    input_list[high] = temp;

    // low_pointer is pointing to the current sorting position
    return low_pointer;
}

function iter_sort(input_list, low, high) {
    if (high > low) {
        let mid = partition(input_list, low, high);
        // sort the front part
        iter_sort(input_list, low, mid - 1);
        // sort the following part
        iter_sort(input_list, mid + 1, high);
    }
}

function quicksort(list) {
    iter_sort(list, 0, list.length - 1);
    return list;
}

function main() {
    // example input for qn1:
    console.log(gcd(8, 4));
    console.log(gcd(9, 3));
    console.log(gcd(11, 9));

    // example input in qn2:
    console.log(parseCSV(path.join(__dirname, "/test.csv")));

    // example input for qn3:
    console.log(quicksort([6, 5, 1, 9, 8, 7, 10, 25, 1, 5, 6]));
}

main();

module.exports.gcd = gcd;
module.exports.parseCSV = parseCSV;
module.exports.quicksort = quicksort;