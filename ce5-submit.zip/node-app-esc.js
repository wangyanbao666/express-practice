// need to install the dependencies using the following command:
// npm i
var express = require("express");
var app = express();

app.use(express.static("images"));
app.use(express.static("css"));
app.set("view engine", "ejs");

app.get("/", (req, res) => {
    res.render("index");
});

app.get("/about", (req, res) => {
    res.render("about");
});

app.get("/contact", (req, res) => {
    res.render("contact");
});

app.get("*", (req, res) => {
    res.render("error");
});

app.listen(5000);
